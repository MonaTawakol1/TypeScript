//array that accept  number only 
var arr1: number[] = [1, 2, 3];
arr1.push(4);
//console.log(arr1);
var arr2: Array<number> = [1, 2, 3];
arr2.push(4);
// console.log(arr2);

// array that accept string and number only and print all items
const mixedArray: (string | number)[] = ["JavaScript", 1, "Jquery", 12, "TypeScript",123];
for ( let i=0 ; i<mixedArray.length ;i++){
    console.log(mixedArray[i]);
}

//variable that accept number and Boolean only 
var arr3: ( number | boolean)[];
arr3 = [1, 2, true];
arr3.push(3);
arr3.push(false);
//console.log(arr3);
var New :number | boolean
 New = 1;
 //console.log(New);
 New = true;
 //console.log(New);


 // function with two parameter try to call it without any parameter “handling”
function  Subtract(x1?:number , x2?:number):any{
    if (x2 !== undefined && x1 !== undefined) return x1 - x2;
        if (x1 !== undefined) return x1;
         return `No Thing To Return`;
}
Subtract();


// Create class Employee implement IEmployee
class Geo{
    lat :number;
    lng:number;
}
class Address {
    street :string;
    suite: string | number;
    city: string;
    zipcode: string;
    geo :Geo;
}
interface IEmployee{
    id:number;
    name:string;
    email:any;
    address :Address;
   // username:string;
}
class Employee implements  IEmployee {
 id:number;
 name:string;
 private username:string;
 email: any;
public address: Address;

constructor(data: any) {
    this.id = data.id;
    this.name = data.name;
    this.username = data.username;
    this.email = data.email;
    this.address = data.address;
}
}

const employeeData = {
    "id": 1,
    "name": "Leanne Graham",
    "username": "Bret", 
    "email": "Sincere@april.biz",
    "address": {
        "street": "Kulas Light",
        "suite": "Apt. 556",
        "city": "Gwenborough",
        "zipcode": "92998-3874",
        "geo": {
            "lat": -37.3159,
            "lng": 81.1496
        }
    }
};
const employee = new Employee(employeeData);
//console.log(employee);


//Create class manager inherit from employee class
class Manager extends Employee{
    constructor(data:any, address:Address){
        super(data);
        this.address=address;
    } 
     PrintAddress(address:Address):void {
        console.log(address);  
    }    
}
let NewAddress:Address={
    "street": "Kulas Light",
    "suite": "Apt. 556",
    "city": "Gwenborough",
    "zipcode": "92998-3874",
    "geo": {
        "lat": -37.3159,
        "lng": 81.1496
    }
}
let ManagerPerson = new Manager ( employeeData, NewAddress );
ManagerPerson.PrintAddress(NewAddress);

// Account Class Implement IAccount
//class Saving Saving_Account inherit  Account
//class Curren_Account inherit  Account
interface IAccount{
    Date_of_opening: Date;
    AddCustomer(Customer:any):void ;
    RemoveCustomer(Customer:any):void;  
}

class Account{
    Acc_no :number;
    Balance: number;
    Date_of_opening: Date;
    AddCustomer(Customer:any):void {
        console.log("Cutomer Added");  
    }  
    RemoveCustomer(Customer:any):void {
        console.log("Cutomer Removed");  
    }  
    DebitAmount(Customer:any):void {
        console.log("Amount ");  
    } 
    CreditAmount(Customer:any):void {
        console.log("Amount ");  
    }   
    getBalance(Customer:any):void {
        console.log("Amount ");  
    }  
     constructor(accNo: number, balance: number, dateOfOpening: Date) {
        this.Acc_no = accNo;
        this.Balance = balance;
        this.Date_of_opening = dateOfOpening;
    }
}

class Saving_Account extends Account//it  implements IAccount Because Account implements it
{
    Date_of_opening: Date;
    min_Balance:number;
    AddCustomer(Customer:any):void {
        console.log("Cutomer Added");  
    }  
    RemoveCustomer(Customer:any):void {
        console.log("Cutomer Removed");  
    }  
    constructor(accNo: number, balance: number, dateOfOpening: Date, minBalance:number) {
        super(accNo, balance, dateOfOpening);
        this.min_Balance =minBalance;
    }
}

class Curren_Account extends Account //it  implements IAccount Because Account implements it
{
    Date_of_opening: Date;
    Interest_rate:number;
    AddCustomer(Customer:any):void {
        console.log("Cutomer Added");  
    }
    RemoveCustomer(Customer:any):void {
        console.log("Cutomer Removed");  
    }  
    constructor(accNo: number, balance: number, dateOfOpening: Date, interestRate: number) {
        super(accNo, balance, dateOfOpening);
        this.Interest_rate = interestRate;
    }
}