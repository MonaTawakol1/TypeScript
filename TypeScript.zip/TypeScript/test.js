var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
//1-array that accept  number only 
var arr1 = [1, 2, 3];
arr1.push(4);
//console.log(arr1);
var arr2 = [1, 2, 3];
arr2.push(4);
// console.log(arr2);
// array that accept string and number only and print all items
var mixedArray = ["JavaScript", 1, "Jquery", 12, "TypeScript", 123];
for (var i = 0; i < mixedArray.length; i++) {
    console.log(mixedArray[i]);
}
//3-variable that accept number and Boolean only 
var arr3;
arr3 = [1, 2, true];
arr3.push(3);
arr3.push(false);
//console.log(arr3);
var New;
New = 1;
console.log(New);
New = true;
console.log(New);
function Subtract(x1, x2) {
    if (x2 !== undefined && x1 !== undefined)
        return x1 - x2;
    if (x1 !== undefined)
        return x1;
    return "No Thing To Return";
}
Subtract();
var Geo = /** @class */ (function () {
    function Geo() {
    }
    return Geo;
}());
var Address = /** @class */ (function () {
    function Address() {
    }
    return Address;
}());
var Employee = /** @class */ (function () {
    function Employee(data) {
        this.id = data.id;
        this.name = data.name;
        this.username = data.username;
        this.email = data.email;
        this.address = data.address;
    }
    return Employee;
}());
var employeeData = {
    "id": 1,
    "name": "Leanne Graham",
    "username": "Bret",
    "email": "Sincere@april.biz",
    "address": {
        "street": "Kulas Light",
        "suite": "Apt. 556",
        "city": "Gwenborough",
        "zipcode": "92998-3874",
        "geo": {
            "lat": -37.3159,
            "lng": 81.1496
        }
    }
};
var employee = new Employee(employeeData);
//console.log(employee);
var Manager = /** @class */ (function (_super) {
    __extends(Manager, _super);
    function Manager(data, address) {
        var _this = _super.call(this, data) || this;
        _this.address = address;
        return _this;
    }
    Manager.prototype.PrintAddress = function (address) {
        console.log(address);
        // console.log(${address},'Is Manager Address');    
    };
    return Manager;
}(Employee));
var NewAddress = {
    "street": "Kulas Light",
    "suite": "Apt. 556",
    "city": "Gwenborough",
    "zipcode": "92998-3874",
    "geo": {
        "lat": -37.3159,
        "lng": 81.1496
    }
};
var ManagerPerson = new Manager(employeeData, NewAddress);
ManagerPerson.PrintAddress(NewAddress);
var Account = /** @class */ (function () {
    function Account(accNo, balance, dateOfOpening) {
        this.Acc_no = accNo;
        this.Balance = balance;
        this.Date_of_opening = dateOfOpening;
    }
    Account.prototype.AddCustomer = function (Customer) {
        console.log("Cutomer Added");
    };
    Account.prototype.RemoveCustomer = function (Customer) {
        console.log("Cutomer Removed");
    };
    Account.prototype.DebitAmount = function (Customer) {
        console.log("Amount ");
    };
    Account.prototype.CreditAmount = function (Customer) {
        console.log("Amount ");
    };
    Account.prototype.getBalance = function (Customer) {
        console.log("Amount ");
    };
    return Account;
}());
var Saving_Account = /** @class */ (function (_super) {
    __extends(Saving_Account, _super);
    function Saving_Account(accNo, balance, dateOfOpening, minBalance) {
        var _this = _super.call(this, accNo, balance, dateOfOpening) || this;
        _this.min_Balance = minBalance;
        return _this;
    }
    Saving_Account.prototype.AddCustomer = function (Customer) {
        console.log("Cutomer Added");
    };
    Saving_Account.prototype.RemoveCustomer = function (Customer) {
        console.log("Cutomer Removed");
    };
    return Saving_Account;
}(Account));
var Curren_Account = /** @class */ (function (_super) {
    __extends(Curren_Account, _super);
    function Curren_Account(accNo, balance, dateOfOpening, interestRate) {
        var _this = _super.call(this, accNo, balance, dateOfOpening) || this;
        _this.Interest_rate = interestRate;
        return _this;
    }
    Curren_Account.prototype.AddCustomer = function (Customer) {
        console.log("Cutomer Added");
    };
    Curren_Account.prototype.RemoveCustomer = function (Customer) {
        console.log("Cutomer Removed");
    };
    return Curren_Account;
}(Account));
